//
//  ViewController.h
//  DMManageMultipleApp
//
//  Created by gamin on 15/10/9.
//  Copyright © 2015年 gamin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

