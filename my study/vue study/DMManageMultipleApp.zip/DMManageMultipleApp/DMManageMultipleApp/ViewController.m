//
//  ViewController.m
//  DMManageMultipleApp
//
//  Created by gamin on 15/10/9.
//  Copyright © 2015年 gamin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *nameLab;
@property (weak, nonatomic) IBOutlet UILabel *markLab;
@property (weak, nonatomic) IBOutlet UILabel *differenceLab;




@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    //不同应用 可以这里完成不同功能的操作
    NSString *judgeMark = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"JudgeMark"];
    NSString *appName   = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"];

    if ([judgeMark isEqualToString:@"1"]) {
        //第一个应用
        _nameLab.text = appName;
        _markLab.text = judgeMark;
        _differenceLab.text = @"DMManageMultipleApp";
        
    }else if([judgeMark isEqualToString:@"2"]){
        //第二个应用
        _nameLab.text = appName;
        _markLab.text = judgeMark;
        _differenceLab.text = @"DMManageMultipleApp-two";

    }else if([judgeMark isEqualToString:@"3"]){
        //第三个应用
        _nameLab.text = appName;
        _markLab.text = judgeMark;
        _differenceLab.text = @"DMManageMultipleApp-three";
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
