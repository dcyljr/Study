//
//  main.m
//  DMManageMultipleApp
//
//  Created by gamin on 15/10/9.
//  Copyright © 2015年 gamin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
