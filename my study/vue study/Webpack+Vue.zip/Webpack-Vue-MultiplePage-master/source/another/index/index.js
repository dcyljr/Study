import Vue from 'vue'
import App from './app'

new Vue({
  el: 'body',
  components: { App }
})